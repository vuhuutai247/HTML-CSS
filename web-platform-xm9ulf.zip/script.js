console.log('Hello!');
let board = document.getElementById('board');
let context = board.getContext('2d');
context.fillStyle = '#aaa';
context.fillRect(0, 0, board.width, board.height);

class Rect {
  constructor(x, y, width, height) {
    this.x = x;
    this.y = y;
    this.w = width;
    this.h = height;
  }

  draw(color = 'red') {
    let board = document.getElementById('board');
    let context = board.getContext('2d');
    context.fillStyle = color;
    context.fillRect(this.x, this.y, this.w, this.h);
  }
}

// xác định va chạm giữa 2 hình chữ nhật (đối tượng Rect)
function isCollision(rect1, rect2) {
  let distX = rect1.x + rect1.w / 2 - (rect2.x + rect2.w / 2);
  if (distX < 0) distX = -distX;

  const distW = (rect1.w + rect2.w) / 2;

  let distY = rect1.y + rect1.h / 2 - (rect2.y + rect2.h / 2);
  if (distY < 0) distY = -distY;

  const distH = (rect1.h + rect2.h) / 2;

  return distX <= distW && distY <= distH;
}

let rect1 = new Rect(10, 10, 100, 100);
rect1.draw();

let rect2 = new Rect(90, 0, 100, 100);
rect2.draw('blue');

function isCollision2(rect1, rect2) {
  return rect2.x <= rect1.x + rect1.w;
}
