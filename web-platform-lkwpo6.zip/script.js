console.log('Hello!');
let board = document.getElementById('board');
let context = board.getContext('2d');
context.fillStyle = '#aaa';
context.fillRect(0, 0, board.width, board.height);
class Circle {
  constructor(x, y, radius) {
    this.x = x;
    this.y = y;
    this.radius = radius;
  }

  draw(color = 'red') {
    let board = document.getElementById('board');
    let context = board.getContext('2d');
    context.beginPath();
    context.arc(this.x, this.y, this.radius, 0, 2 * Math.PI);
    context.strokeStyle = color;
    context.stroke();
    context.closePath();
  }
}

class Rect {
  constructor(x, y, width, height) {
    this.x = x;
    this.y = y;
    this.w = width;
    this.h = height;
  }
  draw(color = 'red') {
    let board = document.getElementById('board');
    let context = board.getContext('2d');
    context.fillStyle = color;
    context.fillRect(this.x, this.y, this.w, this.h);
  }
}

function checkCollision(cir, rect) {
  let Ax = cir.x;
  let Ay = cir.y;

  let rect_left = rect.x;
  let rect_top = rect.y;
  let rect_right = rect.x + rect.w;
  let rect_bottom = rect.y + rect.h;

  if (cir.x < rect_left) Ax = rect_left;
  else if (cir.x > rect_right) Ax = rect_right;

  if (cir.y < rect_top) Ay = rect_top;
  else if (cir.y > rect_bottom) Ay = rect_bottom;

  let dx = cir.x - Ax;
  let dy = cir.y - Ay;

  return dx * dx + dy * dy <= cir.radius * cir.radius;
}

let rect1 = new Rect(0, 0, 100, 100);
rect1.draw();
let c1 = new Circle(200, 30, 40);
c1.draw();

console.log(checkCollision(c1, rect1));
